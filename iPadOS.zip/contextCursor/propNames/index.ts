const propNames = {
  dataAttr: "data-ccursor",
  noPadding: "noPadding",
  noParallax: "noParallax",
  lift: "lift",
};

export default propNames;
