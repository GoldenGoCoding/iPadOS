interface CProps {
  radius?: number;
  transitionSpeed?: number;
  parallaxIndex?: number;
  hoverPadding?: number;
}
