const prod_Path = "../lib";
const src_Path = "src";
const preview_Path = "preview";

module.exports = {
  prod_Path,
  src_Path,
  preview_Path,
};
